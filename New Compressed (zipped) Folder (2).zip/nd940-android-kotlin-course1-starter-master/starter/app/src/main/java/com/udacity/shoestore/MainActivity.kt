package com.udacity.shoestore

import android.os.Bundle
import android.text.Editable
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.activity_main.*
import timber.log.Timber


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Timber.plant(Timber.DebugTree())

    }
    private lateinit var currentFrag: Fragment

    //Shoe List Global Vars-------------------------------
    private val _shoe = mutableListOf<String>()
    private val shoe: MutableList<String>
        get() = _shoe
    private var shoeSet = ""
    private var shoeData = mutableMapOf("Google Shoe" to listOf("Google", "5-10", "Description"),
        "Kotlin Shoe" to listOf("Kotlin", "5-10", "Description"),
        "Java Shoe" to listOf("Java", "5-10", "Description"),
        "Android Shoe" to listOf("Android", "5-10", "Description"),
        "Udacity Shoe" to listOf("Udacity", "5-10", "Description"))

    override fun onStart() {
        super.onStart()
        singleFrag(loginfragment)
        shoe.add("Google Shoe")
        shoe.add("Kotlin Shoe")
        shoe.add("Java Shoe")
        shoe.add("Android Shoe")
        shoe.add("Udacity Shoe")
        run()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        when (currentFrag) {
            loginfragment -> {
                val editEmail = findViewById<EditText>(R.id.Email)
                val editPassword = findViewById<EditText>(R.id.password)
                val loginButton = findViewById<Button>(R.id.login2)
                val newAccount = findViewById<Button>(R.id.newAccount)

                loginButton.setOnClickListener {
                    if (editEmail.text.toString() == "example@example.com" && editPassword.text.toString() == "12345") {
                        singleFrag(welcomfragment)
                    }

                }

                newAccount.setOnClickListener {
                    singleFrag(registerfragment)
                }
            }
            registerfragment -> {
                val editEmail = findViewById<EditText>(R.id.Email)
                val editPassword = findViewById<EditText>(R.id.password)
                val loginButton = findViewById<Button>(R.id.Register)
                val newAccount = findViewById<Button>(R.id.backLogin)

                loginButton.setOnClickListener {
                    if (editEmail.text.toString() != "" && editPassword.text.toString() != "") {
                        singleFrag(welcomfragment)
                    }

                }

                newAccount.setOnClickListener {
                    singleFrag(loginfragment)
                }
            }
            welcomfragment -> {
                val button = findViewById<Button>(R.id.button)
                button.setOnClickListener {
                    singleFrag(instructionsfragment)
                }
            }
            instructionsfragment -> {
                val button = findViewById<Button>(R.id.button2)
                button.setOnClickListener {
                    singleFrag(shoelistfragment)
                }
            }
            shoelistfragment -> {

                val logout = findViewById<Button>(R.id.button3)
                logout.setOnClickListener {
                    singleFrag(loginfragment)
                }

                val addNew = findViewById<Button>(R.id.button7)
                addNew.setOnClickListener {
                    val newShoe = findViewById<EditText>(R.id.editTextTextPersonName)
                    if (newShoe.text.toString() != "") {
                        shoe.add(newShoe.text.toString())
                        newShoe.text.clear()

                        val linearLayout = findViewById<LinearLayout>(R.id.linear_layout)
                        linearLayout.removeAllViews()
                        run()
                    }
                }
            }
        }
    }

    private fun singleFrag(fragment: Fragment) {
        supportFragmentManager.commit {
            hide(loginfragment)
            hide(registerfragment)
            hide(shoedetailfragment)
            hide(welcomfragment)
            hide(instructionsfragment)
            hide(shoelistfragment)
            show(fragment)
        }
        currentFrag = fragment

    }

    private fun run() { //For the Shoe list
        val linearLayout = findViewById<LinearLayout>(R.id.linear_layout)
        linearLayout.removeAllViews()
        for (item in shoe) {
            val view = TextView(this)
            view.text = item
            val actionButton = FloatingActionButton(this)

            linearLayout.addView(view)
            linearLayout.addView(actionButton)

            actionButton.setOnClickListener {
                shoeSet = item
                detail()
                singleFrag(shoedetailfragment)
            }


        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        //Stops the user
    }

    private fun detail() {
        val linearLayout = findViewById<LinearLayout>(R.id.linearLayoutDetail)
        linearLayout.removeAllViews()

        val linearLayoutTwo = findViewById<LinearLayout>(R.id.linearLayoutDetailtwo)
        linearLayoutTwo.removeAllViews()

        val name = TextView(this)

        name.text = shoeSet
        name.textSize = 20F
        val company = EditText(this)
        val size = EditText(this)
        val description = EditText(this)
        company.textSize = 10F
        size.textSize = 10F
        description.textSize = 10F
        company.hint = "Price"
        size.hint = "Size"
        description.hint = "Description"

        val companyText = TextView(this)
        val sizeText = TextView(this)
        val descriptionText = TextView(this)
        companyText.textSize = 15F
        sizeText.textSize = 15F
        descriptionText.textSize = 15F

        val blankText = TextView(this)
        blankText.textSize = 30F
        blankText.text = ""

        if (shoeData[shoeSet] != arrayListOf<String>()) {
            company.text = Editable.Factory.getInstance().newEditable(shoeData[shoeSet]?.get(0))
            size.text = Editable.Factory.getInstance().newEditable(shoeData[shoeSet]?.get(1))
            description.text = Editable.Factory.getInstance().newEditable(shoeData[shoeSet]?.get(2))
        } else if (shoeSet != "") {
            shoeData[shoeSet] = arrayListOf(shoeSet, "5-10", "Description")

            company.text = Editable.Factory.getInstance().newEditable(shoeSet)
            size.text = Editable.Factory.getInstance().newEditable("5-10")
            description.text = Editable.Factory.getInstance().newEditable("Description")
        } else {
            company.text = Editable.Factory.getInstance().newEditable("Oh no!")
            size.text = Editable.Factory.getInstance().newEditable("An error has happened")
            description.text = Editable.Factory.getInstance().newEditable("Please go back and open the details again")
        }

        val buttonBack = findViewById<Button>(R.id.button4)
        buttonBack.setOnClickListener {
            singleFrag(shoelistfragment)
        }

        val buttonCancel = findViewById<Button>(R.id.button6)
        buttonCancel.setOnClickListener {
            shoeData.remove(shoeSet)
            shoeData[shoeSet] = arrayListOf(shoeSet, "5-10", "Description")
        }

        val buttonSubmit = findViewById<Button>(R.id.button5)
        buttonSubmit.setOnClickListener {
            shoeData[shoeSet] = arrayListOf(company.text.toString(),
                size.text.toString(),
                description.text.toString())
        }

        companyText.text = company.text
        sizeText.text = size.text
        descriptionText.text = description.text

        linearLayoutTwo.addView(blankText)
        linearLayoutTwo.addView(companyText)
        linearLayoutTwo.addView(sizeText)
        linearLayoutTwo.addView(descriptionText)

        linearLayout.addView(name)
        linearLayout.addView(company)
        linearLayout.addView(size)
        linearLayout.addView(description)
    }

}
