package com.udacity.shoestore

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.udacity.shoestore.databinding.ShoeDetailsBinding
import com.udacity.shoestore.models.ShoeListModel

class ShoeList: Fragment() {
    private lateinit var shoelst: ShoeListModel
    private lateinit var binding: ShoeDetailsBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.shoe_list, container, false)
//        super.onCreate(savedInstanceState)
//
//
//        shoelst = ViewModelProvider(requireActivity()).get(ShoeListModel::class.java)
//        binding = DataBindingUtil.inflate(
//            inflater, R.layout.shoe_list, container,
//            false
//        )
//
//
//        return binding.root
        return view
    }

}