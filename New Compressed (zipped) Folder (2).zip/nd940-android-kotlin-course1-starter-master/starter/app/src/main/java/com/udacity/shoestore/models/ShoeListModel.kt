package com.udacity.shoestore.models

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ShoeListModel: ViewModel() {
    private lateinit var _shoesList: MutableLiveData<List<Shoe>>
    val shoesList: MutableLiveData<List<Shoe>>
        get() = _shoesList

    var errShoeName = MutableLiveData<Boolean>()
    var errCompany = MutableLiveData<Boolean>()
    var errShoeSize = MutableLiveData<Boolean>()
    var errDescription = MutableLiveData<Boolean>()

    private var _eventAddShoe = MutableLiveData<Boolean>()
    val eventAddShoe: LiveData<Boolean>
        get() = _eventAddShoe

    init {
        loadInitialShoeList()
    }

    public fun addShoe(shoe: Shoe) {
        if (shoeExist(shoe)) {
            _shoesList.value = _shoesList.value?.plus(shoe)
            _eventAddShoe.value = true
        }
    }

    private fun loadInitialShoeList() {
        _shoesList = MutableLiveData<List<Shoe>>().apply {
            value = mutableListOf(
                Shoe(
                    "Google Shoe",
                    10.0,
                    "Google",
                    "Description"
                ),
                Shoe(
                    "Kotlin Shoe",
                    10.0,
                    "Kotlin",
                    "Description"
                ),
                Shoe(
                    "Java Shoe",
                    10.0,
                    "Java",
                    "Description"
                ),
                Shoe(
                    "Android Shoe",
                    10.0,
                    "Android",
                    "Description"
                ),
                Shoe(
                    "Udacity Shoe",
                    10.0,
                    "Udacity",
                    "Description"
                )
            )
        }
    }

    private fun shoeExist(shoe: Shoe): Boolean {
        var result = true
        if (shoe.name.isEmpty()) {
            errShoeName.value = true
            result = false
        }
        if (shoe.company.isEmpty()) {
            errCompany.value = true
            result = false
        }
        if (shoe.size == null) {
            errShoeSize.value = true
            result = false
        }
        if (shoe.description.isEmpty()) {
            errDescription.value = true
            result = false
        }
        return result
    }

    fun onAddShoeFinished() {
        _eventAddShoe.value = false
        errShoeName.value = false
        errCompany.value = false
        errShoeSize.value = false
        errDescription.value = false
    }
}